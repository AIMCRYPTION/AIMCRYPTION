# Security Policy

## Supported Versions

The following versions will receive security updates.

| Version | Supported          |
| ------- | ------------------ |
| 4.x     | :white_check_mark: |
| < 4.0   | :x:                |

## Reporting a Vulnerability

Please report a vulnerbility directly to me at Aimcryption@gmail.com
